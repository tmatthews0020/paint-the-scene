<nav class="footer bg-dark mt-3 text-white">
  <div class="container pt-3">
    <div class="row text-center justify-content-center">
      <div class="col-6">Simply Smart Travel - Copyright <?php echo date("Y") ?> </div>
    </div>
    <div class="row text-center justify-content-center">
      <div class="col-6"></div>
    </div>
  </div>
</nav>
