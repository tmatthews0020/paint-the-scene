

requires npm and grunt

`npm install -g grunt-cli`
